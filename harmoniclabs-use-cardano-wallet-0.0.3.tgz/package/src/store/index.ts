import produce from 'immer';
import { create } from 'zustand';
import { NetworkId, WalletApi, WalletName } from '../typescript/cip30';
import { parseBalance, toWalletInfo } from '../utils';
import { fromHex } from '@harmoniclabs/uint8array-utils';
import { encodeBech32 } from '@harmoniclabs/crypto';

export interface WalletInfo {
  name: WalletName;
  icon?: string | undefined;
  displayName: string;
}

export type State = {
  isConnected: boolean;
  isConnecting: boolean;
  isRefetchingBalance: boolean;

  detectedWallets: WalletInfo[];

  address: null | string;

  rewardAddress: null | string;

  /**
   * The wallet that was selected to connect.
   */
  selectedWallet: null | WalletInfo;

  /**
   * The wallet that is currently connected.
   */
  connectedWallet: null | WalletInfo;

  lovelaceBalance: null | number;
  api: null | WalletApi;
  network: null | NetworkId;

  connect: (walletName: WalletName, localStorageKey: string) => Promise<void>;
  getDetectedWallets: () => Promise<void>;
  disconnect: () => void;
  refetchBalance: () => Promise<void>;
};

const defaults = {
  isConnecting: false,
  isConnected: false,
  detectedWallets: [],
  address: null,
  lovelaceBalance: null,
  api: null,
  selectedWallet: null,
  connectedWallet: null,
  network: null,
  isRefetchingBalance: false,
  rewardAddress: null,
};

export const useStore = create<State>()((set, get) => ({
  ...defaults,
  disconnect: () => {
    set((prev: State) => {
      return {
        ...defaults,
        // Keep detected wallets
        detectedWallets: prev.detectedWallets,
      };
    });
  },

  refetchBalance: async () => {
    const api = get().api;

    if (api === null) return;

    set(
      produce((draft: State) => {
        draft.isRefetchingBalance = true;
      })
    );

    const balance = await api.getBalance();
    const lovelace = parseBalance(balance);

    set(
      produce((draft: State) => {
        draft.isRefetchingBalance = false;
        draft.lovelaceBalance = lovelace;
      })
    );
  },

  getDetectedWallets: async () => {
    if (typeof window === 'undefined' || !(window as any).cardano) {
      return;
    }

    const ns = (window as any).cardano;

    set(
      produce((draft: State) => {
        draft.detectedWallets = Object.keys(ns)
          .filter((ns) => Object.values(WalletName).includes(ns as WalletName))
          .map((n) => toWalletInfo(n as WalletName));
      })
    );
  },

  connect: async (walletName: WalletName, localStorageKey: string) => {
    set(
      produce((draft: State) => {
        draft.isConnecting = true;
        draft.selectedWallet = toWalletInfo(walletName);
      })
    );

    try {
      // Exit early if the Cardano dApp-Wallet Web Bridge (CIP 30) has not been injected
      // This can happen in a SSR scenario for example
      if (typeof window === 'undefined' || !(window as any).cardano) {
        throw Error('window.cardano is undefined');
      }

      const api: WalletApi = await (window as any).cardano[walletName].enable();
      let rawAddress = await api.getChangeAddress();
      if (!rawAddress) {
        [rawAddress] = await api.getUsedAddresses();
      }
      if (!rawAddress) {
        [rawAddress] = await api.getUnusedAddresses();
      }

      let [rewardAddress] = await api.getRewardAddresses();

      if (rewardAddress) {
        const buf = fromHex(rewardAddress);
        rewardAddress = encodeBech32(
          buf[0] === NetworkId.MAINNET ? 'stake' : 'stake_test',
          buf
        );
      }

      const addressBytes = fromHex(rawAddress);
      const balance = await api.getBalance();

      const decodedBalance = parseBalance(balance);

      const bechAddr = encodeBech32(
        addressBytes[0] === NetworkId.MAINNET ? 'addr' : 'addr_test',
        addressBytes
      );

      localStorage.setItem(localStorageKey, walletName);

      set(
        produce((draft: State) => {
          draft.isConnecting = false;
          draft.isConnected = true;
          draft.api = api;
          draft.lovelaceBalance = decodedBalance;
          draft.rewardAddress = rewardAddress;
          draft.address = bechAddr;
          draft.network = addressBytes[0] as NetworkId;
          draft.connectedWallet = toWalletInfo(walletName);
        })
      );
    } catch (e) {
      console.error(e);
      set(
        produce((draft: State) => {
          draft.isConnecting = false;
          draft.selectedWallet = null;
        })
      );
    }
  },
}));
export type ReturnVal = {
  connect: (walletName: WalletName, localStorageKey: string) => Promise<void>;
  getDetectedWallets: () => Promise<void>;
  disconnect: () => void;
  refetchBalance: () => Promise<void>;
};

export default function useCardanoWallet(): ReturnVal {
  const store = useStore();
  return {
    connect: store.connect,
    getDetectedWallets: store.getDetectedWallets,
    disconnect: store.disconnect,
    refetchBalance: store.refetchBalance,
  };
}
